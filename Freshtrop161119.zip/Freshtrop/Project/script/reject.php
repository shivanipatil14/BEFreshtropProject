

<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body onload="closeWebsite()">

</body>
</html>

<script type="text/javascript">
	function closeWebsite(){
	alert('Appointment rescheduled');window.close();
}
</script>
